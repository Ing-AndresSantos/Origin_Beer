/**
 * reports.js — Admin Dashboard Sprint 6
 * RF-27 Reporte por producto
 * RF-28 Columnas: fechaCierre, código, cantidad, costoVenta, costoCompra, ganancia, sede
 * RF-30 Admin: todas las sedes consolidadas
 */

requireAuth();
document.getElementById('sidebar').innerHTML = getSidebarNav('../');
initSidebar('reports');
initDate();

// ── State ──────────────────────────────────────────────────────
let reportData   = { summary: {}, rows: [] };
let allBranches  = [];
let filteredRows = [];
let currentPage  = 1;
const PER_PAGE   = 12;
let chartSales   = null;
let chartPayment = null;
let chartBranch  = null;

// ── PALETTE ───────────────────────────────────────────────────
const COLORS = ['#f59e0b','#10b981','#6366f1','#ef4444','#3b82f6','#8b5cf6','#ec4899','#14b8a6'];

// ══════════════════════════════════════════════════════════════
// LOAD
// ══════════════════════════════════════════════════════════════
async function load() {
    showSkeleton(true);
    try {
        const params = buildParams();
        const [rep, branches] = await Promise.all([
            apiFetch(`/api/reports/admin${params}`),
            apiFetch('/api/branches')
        ]);
        reportData  = rep      || { summary: {}, rows: [] };
        allBranches = branches || [];
        populateBranchFilter();
        applyFilter();
        renderSummary(reportData.summary);
        renderCharts(reportData);
    } catch (e) {
        showEmptyState('❌', 'Could not connect to the server');
    } finally {
        showSkeleton(false);
    }
}

function buildParams() {
    const from     = document.getElementById('filterFrom').value;
    const to       = document.getElementById('filterTo').value;
    const branchId = document.getElementById('filterBranch').value;
    const parts    = [];
    if (from)     parts.push(`startDate=${from}`);
    if (to)       parts.push(`endDate=${to}`);
    if (branchId) parts.push(`branchId=${branchId}`);
    return parts.length ? '?' + parts.join('&') : '';
}

function populateBranchFilter() {
    const sel = document.getElementById('filterBranch');
    const cur = sel.value;
    sel.innerHTML = '<option value="">All branches</option>';
    allBranches.filter(b => b.active).forEach(b => {
        sel.innerHTML += `<option value="${b.idBranch}" ${cur == b.idBranch ? 'selected' : ''}>${b.name}</option>`;
    });
}

// ══════════════════════════════════════════════════════════════
// SUMMARY CARDS
// ══════════════════════════════════════════════════════════════
function renderSummary(s) {
    if (!s || Object.keys(s).length === 0) return;
    setEl('kpiTotalSale',    fmt(s.totalSale));
    setEl('kpiTotalProfit',  fmt(s.totalProfit));
    setEl('kpiMargin',       (s.globalMargin || 0) + '%');
    setEl('kpiQty',          (s.totalQty || 0).toLocaleString('es-CO'));
    setEl('kpiInvoices',     (s.totalInvoices || 0).toLocaleString('es-CO'));
    setEl('kpiAvgTicket',    fmt(s.avgTicket));
    setEl('kpiTopProduct',   s.topProductByQty   || '—');
    setEl('kpiTopBranch',    s.topBranch         || '—');
    setEl('kpiTopCashier',   s.topCashier        || '—');
    setEl('kpiTopPayment',   s.topPayMethod      || '—');
    setEl('kpiPeakHour',     s.peakHour          || '—');

    // Color de margen
    const marginEl = document.getElementById('kpiMargin');
    if (marginEl) {
        const v = parseFloat(s.globalMargin || 0);
        marginEl.style.color = v >= 30 ? '#10b981' : v >= 15 ? '#f59e0b' : '#ef4444';
    }
}

// ══════════════════════════════════════════════════════════════
// CHARTS — Chart.js (cargado desde CDN en HTML)
// ══════════════════════════════════════════════════════════════
function renderCharts(data) {
    const s = data.summary || {};

    // ── 1. Barras: Ventas por día ──────────────────────────────
    renderDailyChart(data.rows || []);

    // ── 2. Donut: Métodos de pago ──────────────────────────────
    renderPaymentChart(s.salesByPayMethod || {});

    // ── 3. Barras horizontales: Top productos ──────────────────
    renderProductChart(s.salesByProduct || {});

    // ── 4. Dona: Participación por sede ───────────────────────
    renderBranchChart(s.salesByBranch || {});

    // ── 5. Heatmap: actividad por hora ─────────────────────────
    renderHourlyHeatmap(s.hourlyActivity || {});
}

function renderDailyChart(rows) {
    const daily = {};
    rows.forEach(r => {
        const d = r.closeDate ? r.closeDate.split('T')[0] : '';
        if (!d) return;
        daily[d] = (daily[d] || 0) + parseFloat(r.totalSale || 0);
    });
    const labels = Object.keys(daily).sort();
    const values = labels.map(k => daily[k]);

    const ctx = document.getElementById('chartDaily');
    if (!ctx) return;
    if (chartSales) chartSales.destroy();
    chartSales = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels.map(d => new Date(d + 'T00:00:00').toLocaleDateString('es-CO', { day:'2-digit', month:'short' })),
            datasets: [{
                label: 'Sales',
                data: values,
                backgroundColor: 'rgba(245,158,11,0.7)',
                borderColor: '#f59e0b',
                borderWidth: 1,
                borderRadius: 6
            }]
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            plugins: { legend: { display: false }, tooltip: { callbacks: {
                label: ctx => '$ ' + ctx.raw.toLocaleString('es-CO')
            }}},
            scales: {
                y: { ticks: { color: '#9ca3af', callback: v => '$ ' + Number(v).toLocaleString('es-CO') }, grid: { color: '#1f2937' } },
                x: { ticks: { color: '#9ca3af' }, grid: { display: false } }
            }
        }
    });
}

function renderPaymentChart(data) {
    const ctx = document.getElementById('chartPayment');
    if (!ctx) return;
    if (chartPayment) chartPayment.destroy();
    const labels = Object.keys(data);
    const values = Object.values(data);
    chartPayment = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels,
            datasets: [{ data: values, backgroundColor: COLORS, borderWidth: 2, borderColor: '#111827' }]
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            plugins: { legend: { position: 'bottom', labels: { color: '#9ca3af', padding: 12, font: { size: 11 } } } }
        }
    });
}

function renderProductChart(data) {
    const ctx = document.getElementById('chartProducts');
    if (!ctx) return;
    const sorted  = Object.entries(data).sort((a, b) => b[1] - a[1]).slice(0, 8);
    const labels  = sorted.map(e => e[0]);
    const values  = sorted.map(e => e[1]);
    if (chartBranch) chartBranch.destroy();
    chartBranch = new Chart(ctx, {
        type: 'bar',
        data: {
            labels,
            datasets: [{
                label: 'Units sold',
                data: values,
                backgroundColor: COLORS.slice(0, labels.length),
                borderRadius: 6
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true, maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: { ticks: { color: '#9ca3af' }, grid: { color: '#1f2937' } },
                y: { ticks: { color: '#e5e7eb', font: { size: 11 } }, grid: { display: false } }
            }
        }
    });
}

function renderBranchChart(data) {
    const ctx = document.getElementById('chartBranch');
    if (!ctx) return;
    const labels = Object.keys(data);
    const values = Object.values(data).map(v => parseFloat(v));
    if (window._chartBranch2) window._chartBranch2.destroy();
    window._chartBranch2 = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels,
            datasets: [{ data: values, backgroundColor: COLORS, borderWidth: 2, borderColor: '#111827' }]
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom', labels: { color: '#9ca3af', padding: 10, font: { size: 11 } } },
                tooltip: { callbacks: { label: c => c.label + ': $ ' + Number(c.raw).toLocaleString('es-CO') } }
            }
        }
    });
}

function renderHourlyHeatmap(data) {
    const el = document.getElementById('heatmapGrid');
    if (!el) return;
    const max = Math.max(...Object.values(data), 1);
    let html = '';
    for (let h = 0; h < 24; h++) {
        const cnt = data[h] || 0;
        const pct = Math.round((cnt / max) * 100);
        const bg  = pct > 80 ? '#f59e0b' : pct > 50 ? '#d97706' : pct > 20 ? '#92400e' : '#1f2937';
        html += `<div class="heatmap-cell" style="background:${bg}" title="${h}:00 — ${cnt} orders">
                    <span class="heatmap-hour">${h}</span>
                 </div>`;
    }
    el.innerHTML = html;
}

// ══════════════════════════════════════════════════════════════
// TABLE — RF-27, RF-28
// ══════════════════════════════════════════════════════════════
function applyFilter() {
    const q   = (document.getElementById('search').value || '').toLowerCase();
    const cat = document.getElementById('filterCategory').value;

    filteredRows = (reportData.rows || []).filter(r => {
        const text = `${r.productCode} ${r.productName} ${r.branchName} ${r.cashier}`.toLowerCase();
        const matchQ   = !q   || text.includes(q);
        const matchCat = !cat || r.category === cat;
        return matchQ && matchCat;
    });

    // Populate category filter options
    const catSel = document.getElementById('filterCategory');
    if (catSel.options.length <= 1) {
        const cats = [...new Set((reportData.rows || []).map(r => r.category))].filter(Boolean).sort();
        cats.forEach(c => { catSel.innerHTML += `<option value="${c}">${c}</option>`; });
    }

    currentPage = 1;
    renderTable();
}

function renderTable() {
    const tbody     = document.getElementById('reportsTable');
    const total     = filteredRows.length;
    const totPages  = Math.ceil(total / PER_PAGE) || 1;
    const start     = (currentPage - 1) * PER_PAGE;
    const page      = filteredRows.slice(start, start + PER_PAGE);

    if (!page.length) {
        tbody.innerHTML = `<tr><td colspan="9"><div class="empty-state"><span class="empty-icon">📭</span><p>No data found for this filter</p></div></td></tr>`;
    } else {
        tbody.innerHTML = page.map(r => {
            const profit  = parseFloat(r.profit || 0);
            const margin  = parseFloat(r.margin || 0);
            const mColor  = margin >= 30 ? '#10b981' : margin >= 15 ? '#f59e0b' : '#ef4444';
            const closeD  = r.closeDate ? new Date(r.closeDate).toLocaleString('es-CO', { dateStyle:'short', timeStyle:'short' }) : '—';
            return `<tr>
                <td style="font-size:11px;color:#9ca3af">${closeD}</td>
                <td><span class="badge badge-branch">${r.productCode || '—'}</span></td>
                <td><div style="font-weight:600">${r.productName || '—'}</div><div style="font-size:10px;color:#6b7280">${r.category || ''}</div></td>
                <td style="text-align:center"><strong>${r.quantity}</strong></td>
                <td>$ ${Number(r.unitCostPrice || 0).toLocaleString('es-CO')}</td>
                <td>$ ${Number(r.totalSale || 0).toLocaleString('es-CO')}</td>
                <td>$ ${Number(r.totalCost || 0).toLocaleString('es-CO')}</td>
                <td style="color:${mColor};font-weight:700">$ ${profit.toLocaleString('es-CO')} <span style="font-size:10px">(${margin}%)</span></td>
                <td><span class="badge badge-cat">${r.branchName || '—'}</span></td>
            </tr>`;
        }).join('');
    }

    document.getElementById('pageInfo').textContent =
        `${Math.min(start + 1, total)}–${Math.min(start + PER_PAGE, total)} of ${total}`;
    renderPagination(totPages);
}

function renderPagination(totalPages) {
    const el = document.getElementById('pageBtns');
    let html = `<button onclick="changePage(${currentPage - 1})" ${currentPage === 1 ? 'disabled' : ''}>← Prev</button>`;
    const range = pagRange(currentPage, totalPages);
    range.forEach(p => {
        if (p === '…') html += `<span style="padding:0 6px">…</span>`;
        else html += `<button class="${p === currentPage ? 'active' : ''}" onclick="changePage(${p})">${p}</button>`;
    });
    html += `<button onclick="changePage(${currentPage + 1})" ${currentPage === totalPages ? 'disabled' : ''}>Next →</button>`;
    el.innerHTML = html;
}

function pagRange(cur, total) {
    if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);
    if (cur <= 4)   return [1,2,3,4,5,'…',total];
    if (cur >= total - 3) return [1,'…',total-4,total-3,total-2,total-1,total];
    return [1,'…',cur-1,cur,cur+1,'…',total];
}

function changePage(p) {
    const total = Math.ceil(filteredRows.length / PER_PAGE) || 1;
    if (p < 1 || p > total) return;
    currentPage = p;
    renderTable();
}

// ══════════════════════════════════════════════════════════════
// EXPORT CSV
// ══════════════════════════════════════════════════════════════
function exportCSV() {
    if (!filteredRows.length) { alert('No data to export.'); return; }

    const header = 'Close Date,Product Code,Product,Category,Qty,Unit Cost,Total Sale,Total Cost,Profit,Margin %,Branch,Cashier,Payment\n';
    const body   = filteredRows.map(r => [
        r.closeDate ? new Date(r.closeDate).toLocaleDateString('es-CO') : '',
        r.productCode, `"${r.productName}"`, `"${r.category}"`,
        r.quantity, r.unitCostPrice, r.totalSale, r.totalCost,
        r.profit, r.margin, `"${r.branchName}"`, `"${r.cashier}"`, r.paymentMethod
    ].join(',')).join('\n');

    const blob = new Blob(['\uFEFF' + header + body], { type: 'text/csv;charset=utf-8;' });
    const a    = Object.assign(document.createElement('a'), {
        href: URL.createObjectURL(blob),
        download: `origin-beer-report-${today()}.csv`
    });
    a.click();
}

// ══════════════════════════════════════════════════════════════
// EXPORT PDF
// ══════════════════════════════════════════════════════════════
function exportPDF() {
    if (!filteredRows.length) { alert('No data to export.'); return; }
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ orientation: 'landscape' });
    const s   = reportData.summary || {};
    const u   = getUser();

    // ── Portada ───────────────────────────────────────────────
    doc.setFillColor(17, 24, 39);
    doc.rect(0, 0, 297, 210, 'F');

    doc.setFontSize(28); doc.setTextColor(245, 158, 11);
    doc.text('🍺 Origin Beer', 148, 55, { align: 'center' });

    doc.setFontSize(16); doc.setTextColor(229, 231, 235);
    doc.text('Sales Report — Admin Dashboard', 148, 70, { align: 'center' });

    doc.setFontSize(11); doc.setTextColor(156, 163, 175);
    doc.text(`Generated: ${new Date().toLocaleString('es-CO')}`, 148, 82, { align: 'center' });
    doc.text(`User: ${u.firstName || ''} ${u.lastName || ''}  |  Role: ADMIN`, 148, 90, { align: 'center' });

    // ── KPIs en portada ───────────────────────────────────────
    const kpis = [
        ['Total Sales',    '$ ' + Number(s.totalSale || 0).toLocaleString('es-CO')],
        ['Total Profit',   '$ ' + Number(s.totalProfit || 0).toLocaleString('es-CO')],
        ['Margin',         (s.globalMargin || 0) + '%'],
        ['Invoices',       s.totalInvoices || 0],
        ['Top Branch',     s.topBranch || '—'],
        ['Top Product',    s.topProductByQty || '—']
    ];
    let kx = 20, ky = 115;
    kpis.forEach(([label, val], i) => {
        if (i === 3) { kx = 20; ky = 145; }
        doc.setFillColor(31, 41, 55);
        doc.roundedRect(kx, ky, 80, 22, 3, 3, 'F');
        doc.setFontSize(8);  doc.setTextColor(156, 163, 175); doc.text(label, kx + 5, ky + 8);
        doc.setFontSize(12); doc.setTextColor(245, 158, 11);  doc.text(String(val), kx + 5, ky + 17);
        kx += 88;
    });

    doc.addPage();

    // ── Tabla de detalles ─────────────────────────────────────
    doc.setFontSize(13); doc.setTextColor(245, 158, 11);
    doc.text('Product Sales Detail', 14, 14);
    doc.setFontSize(9);  doc.setTextColor(156, 163, 175);
    doc.text(`Rows: ${filteredRows.length}`, 14, 21);

    doc.autoTable({
        head: [['Close Date','Code','Product','Qty','Unit Cost','Total Sale','Total Cost','Profit','Branch']],
        body: filteredRows.map(r => [
            r.closeDate ? new Date(r.closeDate).toLocaleDateString('es-CO') : '',
            r.productCode, r.productName, r.quantity,
            '$ ' + Number(r.unitCostPrice).toLocaleString('es-CO'),
            '$ ' + Number(r.totalSale).toLocaleString('es-CO'),
            '$ ' + Number(r.totalCost).toLocaleString('es-CO'),
            '$ ' + Number(r.profit).toLocaleString('es-CO') + ' (' + r.margin + '%)',
            r.branchName
        ]),
        startY: 26,
        styles:       { fontSize: 8, cellPadding: 2, textColor: [229,231,235], fillColor: [17,24,39] },
        headStyles:   { fillColor: [245,158,11], textColor: [0,0,0], fontStyle: 'bold' },
        alternateRowStyles: { fillColor: [31,41,55] },
        theme: 'grid'
    });

    // ── Footer ────────────────────────────────────────────────
    const pages = doc.getNumberOfPages();
    for (let i = 1; i <= pages; i++) {
        doc.setPage(i);
        doc.setFontSize(8); doc.setTextColor(107, 114, 128);
        doc.text(`Origin Beer — Confidential | Page ${i} of ${pages}`, 148, 205, { align: 'center' });
    }

    doc.save(`origin-beer-admin-report-${today()}.pdf`);
}

// ══════════════════════════════════════════════════════════════
// UTILS
// ══════════════════════════════════════════════════════════════
function fmt(val) {
    return '$ ' + Number(val || 0).toLocaleString('es-CO', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
}
function today() { return new Date().toISOString().split('T')[0]; }
function setEl(id, val) { const e = document.getElementById(id); if (e) e.textContent = val; }
function showSkeleton(on) {
    document.querySelectorAll('.skeleton').forEach(el => el.style.display = on ? 'block' : 'none');
}
function showEmptyState(icon, msg) {
    document.getElementById('reportsTable').innerHTML =
        `<tr><td colspan="9"><div class="empty-state"><span class="empty-icon">${icon}</span><p>${msg}</p></div></td></tr>`;
}

// Date preset buttons
function setPreset(preset) {
    const now   = new Date();
    const toStr = d => d.toISOString().split('T')[0];
    let from, to = toStr(now);
    if (preset === 'today') {
        from = toStr(now);
    } else if (preset === 'week') {
        const d = new Date(now); d.setDate(d.getDate() - 6);
        from = toStr(d);
    } else if (preset === 'month') {
        from = toStr(new Date(now.getFullYear(), now.getMonth(), 1));
    } else if (preset === 'quarter') {
        from = toStr(new Date(now.getFullYear(), Math.floor(now.getMonth() / 3) * 3, 1));
    }
    document.getElementById('filterFrom').value = from;
    document.getElementById('filterTo').value   = to;
    document.querySelectorAll('.preset-btn').forEach(b => b.classList.remove('active'));
    event.currentTarget.classList.add('active');
    load();
}

// ── INIT ──────────────────────────────────────────────────────
// Default: current month
const _now = new Date();
document.getElementById('filterFrom').value =
    new Date(_now.getFullYear(), _now.getMonth(), 1).toISOString().split('T')[0];
document.getElementById('filterTo').value = _now.toISOString().split('T')[0];
load();