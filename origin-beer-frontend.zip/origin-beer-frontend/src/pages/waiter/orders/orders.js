/**
 * orders.js — Waiter Orders (Read-Only)
 *
 * Waiter puede:
 *  - Ver sus propias órdenes filtradas por sede
 *  - Ver el detalle de cada orden (líneas + total)
 *
 * Waiter NO puede:
 *  - Cerrar/pagar órdenes (acción de Cashier)
 *  - Agregar/quitar productos desde aquí (se hace en Tables)
 *
 * Algorithms:
 *  - Iterativo   : running total al renderizar líneas
 *  - Ordenamiento: TimSort descendente por fecha de apertura
 *
 * FIX: getWaiterSidebar base path corrected from '../../' to '../'
 *      All waiter pages sit at pages/waiter/<section>/, so '../' goes
 *      up one level to pages/waiter/ — the correct root for sibling
 *      section links (dashboard/, tables/, orders/).
 */

requireAuth();
requireRole('WAITER'); // ← guards against wrong-role access

// FIX: was '../../' which resolved to /pages/ (Admin territory).
// Correct value is '../' → resolves to /pages/waiter/ as intended.
document.getElementById('sidebar').innerHTML = getWaiterSidebar('../');
initSidebar('orders');
initDate();

// ── State ──────────────────────────────────────────────────────
let allOrders      = [];
let currentOrderId = null;
let userBranchId   = null;

// ── BRANCH RESOLUTION — same pattern as Cashier and Waiter Tables ─────────
async function resolveUserBranch(userId) {
    try {
        const branches = await apiFetch('/api/branches');
        if (!branches) return null;

        for (const branch of branches) {
            try {
                const res = await fetch(`${API}/api/branches/${branch.idBranch}/users`, {
                    headers: { 'Authorization': `Bearer ${getToken()}` }
                });
                if (!res.ok) continue;
                const users = await res.json();
                if (users.some(u => u.idUser === userId)) {
                    return branch.idBranch;
                }
            } catch (_) {}
        }
    } catch (e) {
        console.error('Could not resolve branch', e);
    }
    return null;
}

// ══════════════════════════════════════════════════════════════
// LOAD
// ══════════════════════════════════════════════════════════════
async function load() {
    const user = getUser();

    if (!userBranchId) {
        userBranchId = await resolveUserBranch(user.idUser);
    }

    if (!userBranchId) {
        document.getElementById('ordersBody').innerHTML =
            `<tr><td colspan="7" class="loading-row">⚠️ No branch assigned to this waiter</td></tr>`;
        return;
    }

    // Fetch orders scoped to this branch, then filter to own orders only
    const orders = await apiFetch(`/api/orders/branch/${userBranchId}`);
    allOrders = (orders || []).filter(o => o.waiter?.idUser === user.idUser);

    updateStats();
    renderOrders(sortOrdersByDate(allOrders));
}

// ══════════════════════════════════════════════════════════════
// Ordenamiento por fecha — TimSort interno de JS
// ══════════════════════════════════════════════════════════════
function sortOrdersByDate(orders) {
    return [...orders].sort((a, b) =>
        new Date(b.openedAt) - new Date(a.openedAt)
    );
}

// ══════════════════════════════════════════════════════════════
// STATS
// ══════════════════════════════════════════════════════════════
function updateStats() {
    const open = allOrders.filter(o => o.status === 'OPEN');
    const paid = allOrders.filter(o => o.status === 'PAID');

    document.getElementById('statTotal').textContent = allOrders.length;
    document.getElementById('statOpen').textContent  = open.length;
    document.getElementById('statPaid').textContent  = paid.length;
}

// ══════════════════════════════════════════════════════════════
// FILTER + RENDER TABLE
// ══════════════════════════════════════════════════════════════
function filterOrders() {
    const q      = document.getElementById('search').value.toLowerCase();
    const status = document.getElementById('filterStatus').value;

    const result = allOrders.filter(o => {
        const text   = `${o.idOrder} ${o.table?.tableNumber || ''}`.toLowerCase();
        const matchQ = !q || text.includes(q);
        const matchS = !status || o.status === status;
        return matchQ && matchS;
    });

    document.getElementById('resultInfo').textContent =
        `${result.length} order${result.length !== 1 ? 's' : ''} found`;
    renderOrders(sortOrdersByDate(result));
}

function renderOrders(orders) {
    const tbody = document.getElementById('ordersBody');
    if (!orders.length) {
        tbody.innerHTML = `<tr><td colspan="7" class="loading-row">No orders found</td></tr>`;
        return;
    }

    tbody.innerHTML = orders.map(o => {
        const isOpen  = o.status === 'OPEN';
        const opened  = o.openedAt ? new Date(o.openedAt).toLocaleString('es-CO') : '—';
        // Backend returns `total` computed from order_detail lines
        const total   = Number(o.total ?? 0);
        return `
        <tr class="${isOpen ? 'row-open' : 'row-paid'}">
            <td><strong>#${o.idOrder}</strong></td>
            <td>🪑 ${o.table?.tableNumber || '—'}</td>
            <td><span class="badge ${isOpen ? 'badge-open' : 'badge-paid'}">${o.status}</span></td>
            <td>${opened}</td>
            <td>—</td>
            <td>$ ${total.toLocaleString('es-CO')}</td>
            <td>
                <button class="btn-action btn-edit" onclick="openDetailModal(${o.idOrder})">👁 View</button>
            </td>
        </tr>`;
    }).join('');
}

// ── Algoritmo Iterativo — suma quantity × salePrice por línea ─────────────
function computeTotal(details) {
    let total = 0;
    for (const d of details) {
        total += (d.quantity || 0) * parseFloat(d.salePrice || 0);
    }
    return total;
}

// ══════════════════════════════════════════════════════════════
// DETAIL MODAL — READ ONLY
// ══════════════════════════════════════════════════════════════
async function openDetailModal(orderId) {
    currentOrderId = orderId;
    document.getElementById('detailOverlay').classList.add('active');
    document.getElementById('detailTitle').textContent = `🧾 Order #${orderId}`;
    document.getElementById('orderLines').innerHTML    =
        '<div class="empty-state"><span class="empty-icon">⏳</span><p>Loading…</p></div>';

    const [order, details] = await Promise.all([
        apiFetch(`/api/orders/${orderId}`),
        apiFetch(`/api/orders/${orderId}/details`)
    ]);

    if (!order) return;

    const isPaid = order.status === 'PAID';
    document.getElementById('detailMeta').textContent =
        `Table ${order.table?.tableNumber || '—'} · ${new Date(order.openedAt).toLocaleString('es-CO')}`;
    document.getElementById('detailStatusBadge').textContent = order.status;
    document.getElementById('detailStatusBadge').className   = `badge ${isPaid ? 'badge-paid' : 'badge-open'}`;

    renderLines(details || []);
}

// ── Algoritmo Recursivo — construye HTML de líneas recursivamente ──────────
function renderLinesRecursive(details, index, accumHtml) {
    if (index >= details.length) return accumHtml;
    const d   = details[index];
    const sub = ((d.quantity || 0) * parseFloat(d.salePrice || 0)).toLocaleString('es-CO');
    const html = `
        <div class="order-line">
            <div class="order-line-info">
                <span class="order-line-name">${d.product?.name || '—'}</span>
                <span class="order-line-meta">$ ${Number(d.salePrice || 0).toLocaleString('es-CO')} c/u</span>
                <span class="order-line-note">${d.note ? '📝 ' + d.note : ''}</span>
            </div>
            <div class="order-line-right">
                <span class="order-line-qty">×${d.quantity}</span>
                <span class="order-line-price">$ ${sub}</span>
            </div>
        </div>`;
    return renderLinesRecursive(details, index + 1, accumHtml + html);
}

function renderLines(details) {
    const el    = document.getElementById('orderLines');
    const total = computeTotal(details);

    if (!details.length) {
        el.innerHTML = `<div class="empty-state"><span class="empty-icon">🛒</span><p>No items</p></div>`;
    } else {
        el.innerHTML = renderLinesRecursive(details, 0, '');
    }

    document.getElementById('orderTotal').textContent = '$ ' + total.toLocaleString('es-CO');
}

// ── Modal helpers ──────────────────────────────────────────────
function openModal(id)  { document.getElementById(id).classList.add('active'); }
function closeModal(id) {
    document.getElementById(id).classList.remove('active');
    if (id === 'detailOverlay') { currentOrderId = null; }
}
function closeIfOutside(e, id) {
    if (e.target === document.getElementById(id)) closeModal(id);
}

// ── Init ───────────────────────────────────────────────────────
load();